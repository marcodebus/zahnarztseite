<?php
include('./inc/head.php');
include('./inc/header.php');
?>




            <section class="background-white  text-center">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-10 col-md-9">
                            <h3 class="color-primary fs-2 fs-lg-3"><strong>
								Behandlungen</strong></h3>
                            <p class="px-lg-4 mt-3"></p>
							
							

						<!--Unterstrich-->
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 						 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
							<span class='icon-Tooth'></span>
							
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 							 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
						<!--ende Unterstrich -->	
							
							<!-- <hr class="short" width="40%" data-zanim='{"from":{"opacity":0,"width":0},"to":{"opacity":1,"width":"4.20873rem"},"duration":0.8}' data-zanim-trigger="scroll"
                            /> -->
							
							
							
							
							
							
							
							
			
						</div>
					</div>
					

					
                    <!--/.row-->
                </div>
                <!--/.container-->
            </section>
       
        






            <section class="background-11">
				
				<img src="balkenBehandlung.png" width="100%">
				
                <div class="container"  >
                    <h3 class="text-center fs-2 fs-md-3">Unsere Leistungen im Überblick</h3>
						<!--Unterstrich-->
					<div style=" text-align: center;">
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 						 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
							<span class='icon-Heart'></span>
							
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 							 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
						<!--ende Unterstrich -->	
					
					</div>
					
					
					
					
					
					
					
					<div class="row">
                        <!--<div class="col-lg-6 pr-0 pr-lg-3">
                            <img class="radius-secondary" src="assets/images/why-choose-us.jpg" alt="" />	
                        </div>-->
						
						 <div class="col-lg-6 px-lg-5 mt-6 mt-lg-0" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                    
							
							<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/wolke.png" style="margin-right: 10px; margin-left: 10px;float:left;">Sanfte und angstfreie Zahnheilkunde:</h5>
										
										 </div>
										<p class="mt-3 px-lg-3">Seit über 20 Jahren behandeln wir Angstpatienten. Wenn auch sie Angst vor der Zahnbehandlung haben, können wir Ihnen helfen.</p>
									
                                </div>
                            </div>
	
							
									<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/team.png" style="margin-right: 10px; margin-left: 10px;float:left;">Kompetente und freundliche Mitarbeiterinnen:</h5>
										 </div>
                                   
										<p class="mt-3 px-lg-3">Der Patient steht bei uns immer im Mittelpunkt. Wir kümmern uns gerne um Ihr Anliegen und Dr. Fuchs nimmt sich Zeit für eine ausführliche Beratung.</p>
									
                                </div>
                            </div>
	
										<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/geld.png" style="margin-right: 10px; margin-left: 10px;float:left;">Preisgünstiger Zahnersatz mit Möglichkeit der Ratenzahlung</h5>
										 </div>
                                   
										<p class="mt-3 px-lg-3"></p>
									
                                </div>
                            </div>
	
							
								<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/fahne.png" style="margin-right: 10px; margin-left: 10px;float:left;">Wir sprechen Ihre Sprache:</h5>
										 </div>
                                   
										<p class="mt-3 px-lg-3">Wir sprechen 5 Sprachen: Deutsch ,Englisch, Türkisch, Französisch und Rumänisch.</p>
									
                                </div>
                            </div>
	
							 
                        </div>
						
                        <div class="col-lg-6 px-lg-5 mt-6 mt-lg-0" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                    
							
									<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/kind.png" style="margin-right: 10px; margin-left: 10px;float:left;">Kinderfreundliche Praxis:</h5>
										 </div>
                                   
										<p class="mt-3 px-lg-3">Unsere Zahnarztpraxis ist selbstverständlich auch auf kleine Patienten vorbereitet. Für Kinder nehmen wir uns besonders viel Zeit und sind so behutsam wie möglich.</p>
									
                                </div>
                            </div>
	
	
									<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/uhr.png" style="margin-right: 10px; margin-left: 10px;float:left;">Flexible Öffnungszeiten:</h5>
										 </div>
                                   
										<p class="mt-3 px-lg-3">Morgensprechstunde ab 7:30 Uhr, Abendsprechstunde bis 19:30 Uhr<br><br><br></p>
									
                                </div>
                            </div>
	
									<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/pokal.png" style="margin-right: 10px; margin-left: 10px;float:left;">Über 25 Jahre Erfahrung in der Zahnmedizin</h5>
										 </div>
                                   
										<p class="mt-3 px-lg-3"></p>
									
                                </div>
                            </div>
	
								<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/wolke.png" style="margin-right: 10px; margin-left: 10px;float:left;">Parkplätze</h5>
										 </div>
                                   
										<p class="mt-3 px-lg-3">direkt vor der Praxis</p>
									
                                </div>
                            </div>
	
                        </div>
						
						
						
                    </div>
					<div style="text-align:center ">
						<br><br><!--abstand vor Bild-->
					<img class="radius-secondary"  src="https://zahnarzt-fuchs-alzenau.de/wp-content/uploads/2019/01/zahnarzt_fuchs_alzenau_behandlung_abgeschlossen.jpg" width="50%"></div>
					
					
					
					
					
					
					
					
					
					
					
					

                    <!--/.row-->
                </div>
                <!--/.container-->
            </section>
			
					
			
			
			
			  <section style="margin:-6%;" >
                <div class="background-holder "style="min-height: 80%; background-image:url(assets/bilder/balken/balken3.png);"> </div>
                <!--/.background-holder-->
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="media">
                                
                                <div class="media-body">
                                    <h3 class="color-BlauerBalken fs-2 fs-lg-3">Rufen Sie uns an. Wir beraten Sie gerne!</h3>
                                        <br/>
										 <h2 style="text-align: right;">
											 
											
											 
											 <img src="assets/bilder/icons/telefonRund.png">
						<!--<span class="icon-Phone-2 fs-5 color-transpraent mr-3" style="transform: translateY(-1rem); background-color: white; border-radius: 20px; padding: 10px; "></span>-->
                                       <span class="color-white" style="text-align: right;">Telefon 06023 31433</span>
                                    </h2>
                                    <!--<div class="row mt-4 pr-lg-10">
                                        <div class="col-md-3 overflow-hidden" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                                            <div class="fs-3 fs-lg-4 mb-0 lh-2 fw-700 color-white mt-lg-5 mt-3" data-zanim='{"delay":0.1}'>52k</div>
                                            <h6 class="fs-0 color-white" data-zanim='{"delay":0.2}'>Cases Solved</h6>
                                        </div>
                                        <div class="col col-lg-3 overflow-hidden" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                                            <div class="fs-3 fs-lg-4 mb-0 lh-2 fw-700 color-white mt-lg-5 mt-3" data-zanim='{"delay":0.1}'>164</div>
                                            <h6 class="fs-0 color-white" data-zanim='{"delay":0.2}'>Trained Experts</h6>
                                        </div>
                                        <div class="w-100 d-flex d-lg-none"></div>
                                        <div class="col-md-3 overflow-hidden" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                                            <div class="fs-3 fs-lg-4 mb-0 lh-2 fw-700 color-white mt-lg-5 mt-3" data-zanim='{"delay":0.1}'>38</div>
                                            <h6 class="fs-0 color-white" data-zanim='{"delay":0.2}'>Branches</h6>
                                        </div>
                                        <div class="col col-lg-3 overflow-hidden" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                                            <div class="fs-3 fs-lg-4 mb-0 lh-2 fw-700 color-white mt-lg-5 mt-3" data-zanim='{"delay":0.1}'>100%</div>
                                            <h6 class="fs-0 color-white" data-zanim='{"delay":0.2}'>Satisfied Clients</h6>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/.row-->
                </div>
                <!--/.container-->			  
            </section>

			 <section class="background-11">
                <div class="container"  >
                    <h3 class="text-center fs-2 fs-md-3">Kontakt</h3>
						<!--Unterstrich-->
					<div style=" text-align: center;">
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 						 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
							<span class='icon-Tooth'></span>
							
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 							 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
						<!--ende Unterstrich -->	
					
					</div>
					
					
					
					
					
					
					
					<div class="row">
                        <!--<div class="col-lg-6 pr-0 pr-lg-3">
                            <img class="radius-secondary" src="assets/images/why-choose-us.jpg" alt="" />	
                        </div>-->
						
						 <div class="col-lg-6 px-lg-5 mt-6 mt-lg-0 " data-zanim-timeline="{}" data-zanim-trigger="scroll">
                    
							
							<div class="overflow-hidden">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.1}'>
                                     
										 <h5 class="fs-0 fs-lg-1">
                                      <img src="assets/bilder/icons/home.png" style="">Zahnarzt Dr. med. dent. Bernhard Fuchs</h5>
										
										
									
                                </div>
                            </div>
	
							
							<div class="overflow-hidden">
                                <div class="" data-zanim='{"delay":0.1}'>
                                   <h5 class="fs-0 fs-lg-1">
                                   <img src="assets/bilder/icons/telefon.png" style="">Telefon 06023 31433</h5>

                                </div>
                            </div>
	
							<div class="overflow-hidden">
                                <div class="" data-zanim='{"delay":0.1}'>    
								<h5 class="fs-0 fs-lg-1">
                                       <img src="assets/bilder/icons/fax.png" style="">Telefax 06023 - 31866</h5>
                                </div>
                            </div>
	
							
							<div class="overflow-hidden">
                                <div class="" data-zanim='{"delay":0.1}'>
										 <h5 class="fs-0 fs-lg-1">
                                     	<img src="assets/bilder/icons/mail.png" style="">willkommen@zahnarzt-fuchs-alzenau.de</h5>
                                </div>
                            </div>
							 
							 
							<div class="overflow-hidden">
                                <div class="" data-zanim='{"delay":0.1}'>
                                     
									<h5 class="fs-0 fs-lg-1">	 
										
									<img src="assets/bilder/icons/uhr.png" style="">Öffnungszeiten</h5>
									<div style="padding:20px;">
										<p>Montag &nbsp; &nbsp; &nbsp; 8:00 – 13:00 und 14:00 – 18:00 Uhr</p>
										<p>Dienstag &nbsp; &nbsp; 8:00 – 13:00 und 14:00 – 18:00 Uhr</p>
										<p>Mittwoch &nbsp; &nbsp; 7:30 – 13:30 Uhr</p>
										<p>Donnerstag 9:00 – 14:00 und 15:00 – 19:00 Uhr</p>
										<p>Freitag &nbsp; &nbsp; &nbsp; &nbsp; 8:00 – 14:00 Uhr</p>
									</div>
                                </div>
                            </div>
							 
                        </div>
						
                        
						 <div class="col-lg-6 pr-0 pr-lg-3">
                            <br><br><img class="radius-secondary" src="https://zahnarzt-fuchs-alzenau.de/wp-content/uploads/2019/01/zahnarzt_fuchs_alzenau_behandlung_abgeschlossen.jpg" alt="">
                        </div>
						
						
						
						
						<!--<div class="col-lg-6 px-lg-5 mt-6 mt-lg-0 " 
							 style=" float: none;
    margin: 0 auto; "data-zanim-timeline="{}" data-zanim-trigger="scroll">
                    
							
								<img class="radius-secondary "  src="https://zahnarzt-fuchs-alzenau.de/wp-content/uploads/2019/01/zahnarzt_fuchs_alzenau_behandlung_abgeschlossen.jpg" width="50%">
					
	
                        </div>-->
						
						
						
                    </div>
					<!--<div style="text-align:center ">
						<br><br>
					<img class="radius-secondary"  src="https://zahnarzt-fuchs-alzenau.de/wp-content/uploads/2019/01/zahnarzt_fuchs_alzenau_behandlung_abgeschlossen.jpg" width="50%"></div>
					-->
					
					
					
					
					
					
					
					
					
					
					

                    <!--/.row-->
                </div>
                <!--/.container-->
            </section>
			
			


           
           
<?php
include('./inc/terminSection.php');
include('./inc/footer.php');
?>

