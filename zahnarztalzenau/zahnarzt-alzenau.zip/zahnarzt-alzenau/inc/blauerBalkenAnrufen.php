			
			
			  <section >
                <div class="background-holder "style="min-height: 80%; background-image:url(assets/bilder/balken/balken3.png);"> </div>
                <!--/.background-holder-->
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="media">
                                
                                <div class="media-body">
                                    <h3 class="color-BlauerBalken fs-2 fs-xs-0 fs-sm-0 fs-lg-3"><?php echo lang('BlauerBalkenStartZ1');?></h3>
                                        <br/><a href="<?php echo lang('TelefonLink');?>" >
										 <h2 style="text-align: right;">
											 <img src="<?php echo lang('BlauerBalkenStartBild');?>">
						<!--<span class="icon-Phone-2 fs-5 color-transpraent mr-3" style="transform: translateY(-1rem); background-color: white; border-radius: 20px; padding: 10px; "></span>-->
                                       <span class="color-white fs-sm-0 fs-sm-0 fs-md-2 fs-lg-3" style="text-align: right;margin:10px; "><?php echo lang('BlauerBalkenStartZ2');?></span>
									</h2></a>
                                    <!--<div class="row mt-4 pr-lg-10">
                                        <div class="col-md-3 overflow-hidden" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                                            <div class="fs-3 fs-lg-4 mb-0 lh-2 fw-700 color-white mt-lg-5 mt-3" data-zanim='{"delay":0.1}'>52k</div>
                                            <h6 class="fs-0 color-white" data-zanim='{"delay":0.2}'>Cases Solved</h6>
                                        </div>
                                        <div class="col col-lg-3 overflow-hidden" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                                            <div class="fs-3 fs-lg-4 mb-0 lh-2 fw-700 color-white mt-lg-5 mt-3" data-zanim='{"delay":0.1}'>164</div>
                                            <h6 class="fs-0 color-white" data-zanim='{"delay":0.2}'>Trained Experts</h6>
                                        </div>
                                        <div class="w-100 d-flex d-lg-none"></div>
                                        <div class="col-md-3 overflow-hidden" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                                            <div class="fs-3 fs-lg-4 mb-0 lh-2 fw-700 color-white mt-lg-5 mt-3" data-zanim='{"delay":0.1}'>38</div>
                                            <h6 class="fs-0 color-white" data-zanim='{"delay":0.2}'>Branches</h6>
                                        </div>
                                        <div class="col col-lg-3 overflow-hidden" data-zanim-timeline="{}" data-zanim-trigger="scroll">
                                            <div class="fs-3 fs-lg-4 mb-0 lh-2 fw-700 color-white mt-lg-5 mt-3" data-zanim='{"delay":0.1}'>100%</div>
                                            <h6 class="fs-0 color-white" data-zanim='{"delay":0.2}'>Satisfied Clients</h6>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/.row-->
                </div>
                <!--/.container-->			  
            </section>