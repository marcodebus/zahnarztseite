<?php 
$bilder = array("https://zahnarzt-fuchs-alzenau.de/wp-content/uploads/revslider/behandlungen/190112-113921-DSC_0798-1000x666.jpg","https://zahn.debus-software.de/zahnarzt-alzenau/assets/bilder/kontaktbilder/zahnarzt_fuchs_alzenau_gruppenbild-2000x1126.jpeg",);


?>