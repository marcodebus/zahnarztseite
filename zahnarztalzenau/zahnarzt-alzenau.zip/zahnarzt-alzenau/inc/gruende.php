<section class="background-11">
                <div class="container"  >
                    <h3 class="text-center fs-2 fs-md-3"><?php echo lang('8GUeber');?></h3>
						<!--Unterstrich--><h4 align="center"><small>Wir sorgen das Wohl Ihrer Zähne und ein strahlendes Lächeln.</small></h4>
					<div style=" text-align: center;">
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 						 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
							<span class='icon-Heart'></span>

						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 							 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
						<!--ende Unterstrich -->

					</div>







					<div class="row">
                        <!--<div class="col-lg-6 pr-0 pr-lg-3">
                            <img class="radius-secondary" src="assets/images/why-choose-us.jpg" alt="" />
                        </div>-->

						 <div class="col-lg-6 px-lg-5 mt-6 mt-lg-0" data-zanim-timeline="{}" data-zanim-trigger="scroll">


							<div class="overflow-visible">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/wolke.png" style="margin-right: 10px; margin-left: 10px;float:left;">Sanfte und angstfreie Zahnheilkunde:</h5>
										 </div>
										<p class="mt-3 px-lg-3">Seit über 20 Jahren behandeln wir Angstpatienten. Wenn auch sie Angst vor der Zahnbehandlung haben, können wir Ihnen helfen.</p>

									<p align="right"><a class="btn btn-icon btn-outline-primary btn-icon-left " href="angstpatient-lachgas-tiefschlaf-vollnarkose.php">
										<span class="icon-Tooth "></span>Mehr Erfahren</a></p>
                                </div>
                            </div>


									<div class="overflow-visible">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/team.png" style="margin-right: 10px; margin-left: 10px;float:left;">Kompetente und freundliche Mitarbeiterinnen:</h5>
										 </div>

										<p class="mt-3 px-lg-3">Der Patient steht bei uns immer im Mittelpunkt. Wir kümmern uns gerne um Ihr Anliegen und Dr. Fuchs nimmt sich Zeit für eine ausführliche Beratung.</p>

									<p align="right"><a class="btn btn-icon btn-outline-primary btn-icon-left " href="team.php">
										<span class="icon-Tooth "></span>Mehr Erfahren</a></p>

                                </div>
                            </div>






									<div class="overflow-visible">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/uhr.png" style="margin-right: 10px; margin-left: 10px;float:left;">Flexible Öffnungszeiten:</h5>
										 </div>

										<p class="mt-3 px-lg-3">Morgensprechstunde ab 7:30 Uhr, Abendsprechstunde bis 19:30 Uhr</p>
									<p align="right"><a class="btn btn-icon btn-outline-primary btn-icon-left " href="oeffnungszeiten.php">
										<span class="icon-Tooth "></span>Mehr Erfahren</a></p>
                                </div>
                            </div>








							 	<div class="overflow-visible">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/pokal.png" style="margin-right: 10px; margin-left: 10px;float:left;">Über 25 Jahre Erfahrung in der Zahnmedizin</h5>
										 </div>

										<p class="mt-3 px-lg-3"></p>

                                </div>
                            </div>








                        </div>

       <div class="col-lg-6 px-lg-5 mt-6 mt-lg-0" data-zanim-timeline="{}" data-zanim-trigger="scroll">





									<div class="overflow-visible">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/kind.png" style="margin-right: 10px; margin-left: 10px;float:left;">Kinderfreundliche Praxis:</h5>
										 </div>

										<p class="mt-3 px-lg-3">Unsere Zahnarztpraxis ist selbstverständlich auch auf kleine Patienten vorbereitet. Für Kinder nehmen wir uns besonders viel Zeit und sind so behutsam wie möglich.</p>
									<p align="right"><a class="btn btn-icon btn-outline-primary btn-icon-left " href="kinderbehandlung.php">
										<span class="icon-Tooth "></span>Mehr Erfahren</a></p>
                                </div>
                            </div>




								<div class="overflow-visible">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/fahne.png" style="margin-right: 10px; margin-left: 10px;float:left;">Wir sprechen Ihre Sprache:<br></h5>
										 </div>

										<p class="mt-3 px-lg-3"><br>Wir sprechen 5 Sprachen: <br>Deutsch ,Englisch, Türkisch,<br> Französisch und Rumänisch. </p><p align="right"><a class="btn btn-icon btn-outline-primary btn-icon-left " href="team.php">
										<span class="icon-Tooth "></span>Mehr Erfahren</a></p>

                                </div>
                            </div>







		   	<div class="overflow-visible">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/geld.png" style="margin-right: 10px; margin-left: 10px;float:left; ">Preisgünstiger Zahnersatz</h5>	<p class="mt-3 px-lg-3">mit Möglichkeit der Ratenzahlung<br><br></p>
										 <p align="right"><a class="btn btn-icon btn-outline-primary btn-icon-left " href="hochwertiger-zahnersatz.php">
										<span class="icon-Tooth "></span>Mehr Erfahren</a></p>
										 </div>

										<p class="mt-3 px-lg-3"></p>

                                </div>


								<div class="overflow-visible">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.2}'>
                                     <div style="margin-bottom: 10px; padding:10px">
										 <h5 class="fs-0 fs-lg-1">
                                       <!--<span class="ion-ios-timer fs-2 mr-2 icon-position-fix fw-600"></span>--><img src="assets/bilder/icons/wolke.png" style="margin-right: 10px; margin-left: 10px;float:left;">Parkplätze</h5>
										 </div>

										<p class="mt-3 px-lg-3">Direkt vor unserer Zahnarztpraxis in Alzenau Hörstein, Roter Rain 9.</p>

                                </div>
                            </div>
                            </div>


                        </div>



                    </div>







                    <!--/.row-->
                </div>
                <!--/.container-->
            </section>
