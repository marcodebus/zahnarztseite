<!--Unterstrich-->
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 						 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
							<span class='<?php echo $icon; ?>'></span>
							
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 							 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
						<!--ende Unterstrich -->	
							
							<!-- <hr class="short" width="40%" data-zanim='{"from":{"opacity":0,"width":0},"to":{"opacity":1,"width":"4.20873rem"},"duration":0.8}' data-zanim-trigger="scroll"
                            /> -->
							
							
							
							
							