					
					<table width="100%"> 
						<tr>
							<td style="width: 50%"><h1 class="fs-2"><?php echo $Ueber;?></h1></td>
							<td class="text-right fs--1" style="width: 50% "><?php echo $Side;?></td>
						</tr>
					</table>