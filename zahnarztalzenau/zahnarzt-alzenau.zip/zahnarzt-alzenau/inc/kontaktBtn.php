<div class="col-lg-12 px-lg-12 mt-6 mt-lg-0" data-zanim-timeline="{}" data-zanim-trigger="scroll">





							 <div class="overflow-hidden" style="margin: 10px;">
                                <div class="px-4 px-sm-0 mt-5" data-zanim='{"delay":0.1}'>
										 <h5 class="fs-0 fs-lg-1">
                                      <img src="assets/bilder/icons/blankPNG.png" style="margin-right: 8px;"><br><br></h5>
                                </div>
                            </div>





							 <div class="overflow-hidden" style="margin: 10px;">
                                <div class="" data-zanim='{"delay":0.1}'>
                                   <h5 class="fs-0 fs-lg-1">
                                   <img src="assets/bilder/icons/home.png" style="margin-right: 8px;"><nobr><?php echo lang('Name');?></nobr></h5>

                                </div>
                            </div>

							<div class="overflow-hidden" style="margin: 10px;">
                                <div class="" data-zanim='{"delay":0.1}'>
                                   <h5 class="fs-0 fs-lg-1">
                                   <img src="assets/bilder/icons/telefon.png" style="margin-right: 8px;"><?php echo lang('Telefon');?></h5>

                                </div>
                            </div>

							<div class="overflow-hidden" style="margin: 10px;">
                                <div class="" data-zanim='{"delay":0.1}'>
								<h5 class="fs-0 fs-lg-1">
                                       <img src="assets/bilder/icons/fax.png" style="margin-right: 8px;"><?php echo lang('Fax');?></h5>
                                </div>
                            </div>


							<div class="overflow-hidden" style="margin: 10px;">
                                <div class="" data-zanim='{"delay":0.1}'>
										 <h5 class="fs-0 fs-lg-1" style="font-size: 75%;">
                                     	<img src="assets/bilder/icons/mail.png" style="margin-right: 8px;"><nobr><?php echo lang('Email');?></nobr></h5>
                                </div>
                            </div>


							<div class="overflow-hidden" style="margin: 10px;">
                                <div class="" data-zanim='{"delay":0.1}'>

									<h5 class="fs-0 fs-lg-1">

									<img src="assets/bilder/icons/uhr.png" style="margin-right: 8px;"><?php echo lang('Open');?></h5>
									<div style="">
							<div class="col-lg-12">
                            <div class="  radius-secondary" align="left" style="padding-left:43px;" >

								<div style="overflow-x:auto;">



								<table>



										<?php
											$array =  array('Mo','Di','Mi','Do','Fr');
											$i =0;
											while ($i < 5){

											     echo"<tr><td>";
												echo "<div style=\"padding-right: 1em; \">";
												 echo lang($array[$i]);
												//echo "</div>";
												echo"</td><td>";
												 echo lang($array[$i].'1');
												//echo"</td><td>";
												 echo lang('und');
												//echo"</td><td>";
												 echo lang($array[$i].'2');
												//echo"</td><td>";
												 echo lang('Uhr');

												//echo"</td><td>";
												echo"</td></tr>";


											$i = $i+1;
											}

										?>




							</table>
								</div>

							</div>
                        </div>

									</div>
                                </div>
                            </div>




                        </div>
