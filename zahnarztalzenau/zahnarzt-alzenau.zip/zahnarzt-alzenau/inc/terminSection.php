			
		

			 <section style="padding-top:0px; margin-top:0px;" class="background-white text-center">
                <div class="container"  >
					<?php 
					
					if ($Behandlung == true){
						include('../inc/termin.php');
					}else{
						include('./inc/termin.php');
					}
					?>
                </div>
                <!--/.container-->
            </section>