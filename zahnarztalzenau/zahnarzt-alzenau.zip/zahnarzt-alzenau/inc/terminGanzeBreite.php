

			<section class="">
                <div class="container"  >
                    <h3 class="text-center ">
	<?php
	if($Kontakttext != ""){
		echo $Kontakttext;
	}else{echo "Zur Terminvereinbarung rufen Sie uns bitte an!";}
	?>
					</h3>
						<!--Unterstrich-->
					<div style=" text-align: center;">
						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 						 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
							<span class='icon-Telephone'></span>

						<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 							 <img src="./assets/bilder/icons/blankPNG.png" />
						</object>
						<!--ende Unterstrich -->
						<div style="padding-top: 50px">
						<a class="btn btn-icon btn-outline-primary btn-icon-left " href="<?php echo lang('TelefonLink');?>">
                                    <span class="icon-Telephone "></span>jetzt anrufen</a>
						</div>
					</div>

                    <!--/.row-->
                </div>
                <!--/.container-->
            </section>
