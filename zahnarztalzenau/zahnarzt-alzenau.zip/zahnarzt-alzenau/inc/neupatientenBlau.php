			
			
		<section>
                <div class="background-holder "style="min-height: 90%; background-image:url(assets/bilder/balken/balken3.png);"> </div>
                <!--/.background-holder-->
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="media">
                                
                                <div class="media-body">
									<div class="row">
                                   		<div class="col-sm-8 col-md-8 col-lg-4 col-xl-4" >
											<h3 class="color-BlauerBalken fs-2 fs-lg-3"><?php echo lang('BlauerBalkenPraxisUeber');?></h3>
                                        	<br/> 
											<img  style="border-radius: 50%" width="90%" src="<?php echo lang('BlauerBalkenPraxisBild');?>">
											<br>
										</div>	
										<div class="col-sm-12 col-md-12 col-lg-8 col-xl-8" style="padding:8px;">
										  <h2 style="text-align: right; position: relative;
top: 50%;
transform: translateY(-50%);">
                                       		<span class="color-white" style="text-align: right;">
												<h5 class="color-white" ><?php echo lang('BlauerBalkenPraxisText');?> </h5> 
											</span>
						 				 </h2>
										</div>
									</div>
                             
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/.row-->
                </div>
                <!--/.container-->			  
            </section>