			<div class="row mt-6">
                  <div class="col">
                       <h3 class="text-center fs-2 fs-md-3"></h3>
                        <!--Unterstrich-->
						<div style=" text-align: center;">
							<!--<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
 						 		<img src="./assets/bilder/icons/blankPNG.png">
							</object>
							<span class="icon-Tooth"></span>
							
							<object data="./assets/bilder/icons/unterstrich.svg" type="image/svg+xml">
								 <img src="./assets/bilder/icons/blankPNG.png">
							</object>-->
					  </div>
                        <div class="col-12">
                            <div class="background-white px-3 mt-6 px-0 py-5 px-lg-5 radius-secondary">

							<?php
									if ($Behandlung == true){
										include('../inc/terminDiv.php');
									}else{
										include('./inc/terminDiv.php');
									}
							?>

                    		</div>
						</div>	
								
								
								
                    </div>
             </div>
					
					