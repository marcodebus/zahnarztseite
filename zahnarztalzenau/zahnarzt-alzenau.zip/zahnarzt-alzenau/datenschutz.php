<?php
	header('Location: impressum.php');
?>